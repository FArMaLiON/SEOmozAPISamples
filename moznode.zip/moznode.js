var request = require("request");
var crypto = require('crypto');

// Get credentials from https://moz.com/products/mozscape/access
mozAccessID = "mozscape-xxxxxxxxxx";
mozSecretKey = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";

mozExpires = parseInt((Date.now() / 1000).toFixed()) + 300;
console.log (mozExpires);
mozStringToSign = mozAccessID+"\n"+mozExpires;
//mozSig = crypto.createHmac('sha1', mozSecretKey).update(mozStringToSign).digest('hex');


mozSig = crypto.createHmac('sha1', mozSecretKey).update(mozStringToSign).digest('base64');
mozSafeSig = encodeURIComponent(mozSig);

mozURL = 'jamesbachini.com';
mozCols = '103079247904'; // Learn more here: https://moz.com/help/guides/moz-api/mozscape/api-reference/url-metrics

mozRequest = "http://lsapi.seomoz.com/linkscape/url-metrics/"+encodeURIComponent(mozURL)+"?Cols="+mozCols+"&AccessID="+mozAccessID+"&Expires="+mozExpires+"&Signature="+mozSafeSig;

request(mozRequest, function (error, response, body) {
 // if (!error && response.statusCode == 200) {
    console.log(body);
 // }
});